def borrarPantalla():
  import os  
  os.system("clear")

def esperarTecla():
  print("\n \t \tDa click en cualquier tecla para continuar ...")
  input() 